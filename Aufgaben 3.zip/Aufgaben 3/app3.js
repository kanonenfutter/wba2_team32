//Notes: added mongoDB, Errorhandling, edited res.post and res.get,
var http = require('http');
var express = require('express');
var mongoDB = require('mongoskin');

var app3 = express();
var server = http.createServer(app3);

// Verbindung zur mongoDB

var db =mongoDB.db('mongodb://localhost/mydb?auto_reconnect=true',{safe: true});

// Collection "planeten" binden

db.bind('planeten');

var planetenCollection = db.planeten;

/* Dokumente einfügen*/

planetenCollection.insert(
    [{
    pname: "Uranus", 
    du: "51100",
    dist:"2877000000"},
    {
    pname: "Mars", 
    du: "6800",
    dist:"227900000"},
    {
    pname: "Venus", 
    du: "12100",
    dist:"108200000"}], function(error, planets) {
        if (error) next(error);
        else console.log('Saved to database!')
    });
    

//Verzeichnisdefinierung fuer den Zugriff von Aussen
app3.use(express.static(__dirname+'/public'));

//benötigt um Informationen des Requests zu parsen
app3.use(express.json());
app3.use(express.urlencoded());

//Errorhandling?
app3.use(function(error, req, res, next) {
    console.error(error.stack);
    res.writeHead(500, 'Ein Fehler ist aufgetreten');
    res.end(error.message);
    
});


//get-response auf die Ressource /planeten
app3.get('/planeten', function (req, res, next) {
    planetenCollection.findItems(function(error, result){
        if (error)
            next(error);
        else{
            res.writeHead(200, {
                'Content-Type': 'application/json'
            });
            res.end(JSON.stringify(result));
        }
    });
});
    

//post-response auf die Ressource /planeten
app3.post('/planeten', function(req, res, next) {
    planetenCollection.insert(req.body, function(error, planetenCollection){
        if (error){
            next(error);
        }
        else {
            res.writeHead(200, 'OK');
            res.write('Daten wurden gespeichert');
            res.end();
        }
    });
});

//Webserver wird auf Port 3000 erstellt mit Ausgabe in der Konsole. Yay.
app3.listen(3000, function(){
	console.log('Express server is running...');
});
    